import React from 'react';
import { useDispatch } from 'react-redux';
import { addToCart } from '../redux/cartSlice';
import styles from './ProductCard.module.css';

const ProductCard = ({ plant }) => {
  const dispatch = useDispatch();

  return (
    <div className={styles.productCard}>
      <img src={plant.image} alt={plant.name} />
      <h3>{plant.name}</h3>
      <p>{plant.description}</p>
      <p>${plant.price}</p>
      <button onClick={() => dispatch(addToCart(plant))}>Add to Cart</button>
    </div>
  );
};

export default ProductCard;
