import React from 'react';
import { useSelector, useDispatch } from 'react-redux';
import { removeFromCart, updateQuantity } from '../redux/cartSlice';
import styles from './ShoppingCart.module.css';

const ShoppingCart = () => {
  const { items, totalQuantity, totalCost } = useSelector(state => state.cart);
  const dispatch = useDispatch();

  return (
    <div className={styles.shoppingCart}>
      <h2>Shopping Cart</h2>
      {items.map(item => (
        <div key={item.id} className={styles.cartItem}>
          <img src={item.image} alt={item.name} />
          <h3>{item.name}</h3>
          <p>Unit Price: ${item.price}</p>
          <input
            type="number"
            value={item.quantity}
            onChange={(e) =>
              dispatch(updateQuantity({ id: item.id, quantity: Number(e.target.value) }))
            }
          />
          <button onClick={() => dispatch(removeFromCart(item.id))}>Remove</button>
        </div>
      ))}
      <div className={styles.cartSummary}>
        <p>Total Items: {totalQuantity}</p>
        <p>Total Cost: ${totalCost.toFixed(2)}</p>
        <button>Checkout</button>
      </div>
    </div>
  );
};

export default ShoppingCart;
