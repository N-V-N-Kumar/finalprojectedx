import React from 'react';
import { useSelector } from 'react-redux';
import { useNavigate } from 'react-router-dom';

const Header = () => {
  const totalQuantity = useSelector(state => state.cart.totalQuantity);
  const navigate = useNavigate();

  return (
    <header>
      <h1 onClick={() => navigate('/')}>Paradise Nursery</h1>
      <div onClick={() => navigate('/cart')}>
        Cart ({totalQuantity})
      </div>
    </header>
  );
};

export default Header;
